//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var myFirtsVar = 70
myFirtsVar = 80

// constante
let myFirstConstant = 90

// explicit type

var myFirstInteger:Int = 90
var myDouble:Double = 1000.5
let myString:String = "Hevada"


print("Calculated value is: \(myFirstInteger * myFirtsVar)")


var arrayList = ["one","Two","Cule"]



arrayList [1]



//function


func getValue(name:String, day:Int) -> String{
    return "Hello \(name), to day is \(day)"
}

func showValues(name:String, ci:Int){
    print(name)
}


getValue("Hector", day:0)





class Person{

    var Name:String
    var CI:String

    
    init(name:String, code:String){
        self.Name = name
        self.CI = code
        
    }
    
    func getNombreCompleto()->String{
        return "Name : \(Name)"
    }

}


var person = Person(name:"Hector", code:"1000")

print(person.getNombreCompleto())


// interface
protocol IEmployee{
    func printSalary()
}


class Employee:Person, IEmployee{
    var PhoneNumber:String
    var Salary:Double
    
    init(nameEmployee:String, ci:String, phoneNumber:String, salary:Double){
        
        self.PhoneNumber = phoneNumber
        self.Salary = salary
        super.init(name: nameEmployee, code: ci)
    }
    
    func getNameAndCi()->String{
        return "Nombre: \(super.Name), CI: \(super.CI)"
    }
    func printSalary() {
        print("Salary : \(self.Salary)" )
    }
}

var employee = Employee(nameEmployee: "Jhonny", ci:"6721331", phoneNumber:"72227776", salary:100000 )

employee.printSalary()

print(employee.getNameAndCi())

protocol IPrintable{
    func printArea()
}


class Cuadrado : IPrintable{
    var LadoX:Int
    var LadoY:Int
    
    init(ladoX:Int, ladoY:Int){
        self.LadoX = ladoX
        self.LadoY = ladoY
    }
    
    func printArea(){
        print("Area Cuadrado: \(self.LadoX * self.LadoY)" )
    }

}

class Circulo : IPrintable{
    var Radio:Double
    
    init(radio:Double){
    self.Radio = radio
    }
    func printArea() {
        print("Area Circulo: \(self.Radio * 3.14)")
    }
}


class Printer{

    
    func PrintShape(objeto:IPrintable){
        objeto.printArea()
    }
}

var printer = Printer()


printer.PrintShape(Cuadrado(ladoX: 12, ladoY: 12))


printer.PrintShape(Circulo(radio: 12))



